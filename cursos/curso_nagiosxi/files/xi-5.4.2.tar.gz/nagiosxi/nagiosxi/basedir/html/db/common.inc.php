<?php
//
// Copyright (c) 2008-2015 Nagios Enterprises, LLC.  All rights reserved.
//  
// $Id$

require_once(dirname(__FILE__) . '/../includes/db.inc.php');
require_once(dirname(__FILE__) . '/queries.inc.php');

