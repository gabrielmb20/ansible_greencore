#!/bin/bash
# Copyright (c) 2008-2016 Nagios Enterprises, LLC.  All rights reserved.

BASEDIR=$(dirname $(readlink -f $0))

# What object should we delete?
if [ $# -ne 2 ]; then
    echo "Incorrect arguments"
    exit
fi

otype=$1
shift
id=$1

if [ 'x${otype}' == 'x' ]; then
exit
fi
if [ 'x${id}' == 'x' ]; then
exit
fi

# Login to NagiosQL
/usr/bin/php -q $BASEDIR/nagiosql_login.php

# Delete the object
cmd="/usr/bin/php -q ${BASEDIR}/nagiosql_delete_${otype}.php --id=${id}"
echo $cmd
$cmd


